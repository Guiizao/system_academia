export const COOKIE_SESSAO = 'df_sessao';
export function registrarAutenticacao(app, auth) {
    app.decorateRequest('usuario', null);
    app.addHook('onRequest', async (req) => {
        const token = req.cookies?.[COOKIE_SESSAO]
            ?? req.headers.authorization?.replace(/^Bearer /, '');
        req.usuario = auth.usuarioDaSessao(token);
    });
}
/** Guarda de rota: exige login e, opcionalmente, um dos papeis. */
export function exigir(...papeis) {
    return async (req, reply) => {
        if (!req.usuario)
            return reply.status(401).send({ erro: 'Faça login para continuar' });
        if (papeis.length && !papeis.includes(req.usuario.papel)) {
            return reply.status(403).send({ erro: 'Seu perfil não tem acesso a isto' });
        }
    };
}
