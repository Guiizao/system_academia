import { diffDias } from './datas.js';
/**
 * Status e SEMPRE derivado -- nunca armazenado.
 * Uma implementacao so, consumida por telas, relatorios, job e bots.
 */
export function statusDoAluno(dataFim, hojeISO, diasAviso) {
    if (!dataFim)
        return 'inativo';
    const dias = diffDias(hojeISO, dataFim);
    if (dias < 0)
        return 'vencido';
    if (dias <= diasAviso)
        return 'vencendo';
    return 'ativo';
}
export function diasParaVencer(dataFim, hojeISO) {
    return dataFim ? diffDias(hojeISO, dataFim) : null;
}
