/** Erro de regra de negocio: vira HTTP 4xx com mensagem legivel. */
export class ErroNegocio extends Error {
    status;
    constructor(message, status = 400) {
        super(message);
        this.status = status;
    }
}
export class ErroNaoEncontrado extends ErroNegocio {
    constructor(message) { super(message, 404); }
}
export class ErroPermissao extends ErroNegocio {
    constructor(message) { super(message, 403); }
}
export class ErroExcessoDeTentativas extends ErroNegocio {
    esperarSeg;
    constructor(message, esperarSeg) {
        super(message, 429);
        this.esperarSeg = esperarSeg;
    }
}
