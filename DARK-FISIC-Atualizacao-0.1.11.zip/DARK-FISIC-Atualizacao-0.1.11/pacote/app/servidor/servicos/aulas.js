import { eq, and, count, ne } from 'drizzle-orm';
import { aula, inscricaoAula, usuario, aluno } from '../db/schema.js';
import { ErroNegocio, ErroNaoEncontrado } from './erros.js';
function diaDaSemana(data) {
    const [a, m, d] = data.split('-').map(Number);
    return new Date(Date.UTC(a, m - 1, d)).getUTCDay();
}
export function criarServicoAulas(db) {
    function inscritos(aulaId, data, q = db) {
        return q.select({ n: count() }).from(inscricaoAula)
            .where(and(eq(inscricaoAula.aulaId, aulaId), eq(inscricaoAula.data, data), ne(inscricaoAula.status, 'cancelado'))).get()?.n ?? 0;
    }
    /** Aulas de uma DATA REAL, com a ocupacao daquela data. */
    function doDia(data) {
        return db.select({
            id: aula.id, nome: aula.nome, hora: aula.hora, duracaoMin: aula.duracaoMin,
            vagas: aula.vagas, local: aula.local, professorNome: usuario.nome,
        }).from(aula)
            .leftJoin(usuario, eq(usuario.id, aula.professorUsuarioId))
            .where(and(eq(aula.diaSemana, diaDaSemana(data)), eq(aula.ativo, true)))
            .orderBy(aula.hora).all()
            .map((a) => ({ ...a, data, inscritos: inscritos(a.id, data) }));
    }
    function listar() {
        return db.select().from(aula).where(eq(aula.ativo, true)).orderBy(aula.diaSemana, aula.hora).all();
    }
    function criar(dados) {
        if (!dados.nome?.trim())
            throw new ErroNegocio('Nome da aula é obrigatório');
        if (!(dados.vagas > 0))
            throw new ErroNegocio('Vagas deve ser maior que zero');
        return db.insert(aula).values(dados).returning().get();
    }
    /** Inscricao por aluno + data. Respeita vagas; duplicada e erro. */
    function inscrever(aulaId, alunoId, data) {
        return db.transaction((tx) => {
            const t = tx;
            const a = t.select().from(aula).where(eq(aula.id, aulaId)).get();
            if (!a)
                throw new ErroNaoEncontrado('Aula não encontrada');
            if (a.diaSemana !== diaDaSemana(data))
                throw new ErroNegocio('Esta aula não acontece nessa data');
            if (!t.select({ id: aluno.id }).from(aluno).where(eq(aluno.id, alunoId)).get()) {
                throw new ErroNaoEncontrado('Aluno não encontrado');
            }
            if (inscritos(aulaId, data, t) >= a.vagas)
                throw new ErroNegocio('Aula lotada');
            try {
                return t.insert(inscricaoAula).values({ aulaId, alunoId, data }).returning().get();
            }
            catch (e) {
                if (String(e.message).includes('UNIQUE'))
                    throw new ErroNegocio('Aluno já inscrito nesta aula');
                throw e;
            }
        });
    }
    /** Ids dos alunos ja inscritos numa sessao: a tela marca e nao oferece de novo. */
    function alunosInscritos(aulaId, data) {
        return db.select({ id: inscricaoAula.alunoId }).from(inscricaoAula)
            .where(and(eq(inscricaoAula.aulaId, aulaId), eq(inscricaoAula.data, data), ne(inscricaoAula.status, 'cancelado'))).all().map((r) => r.id);
    }
    function atualizar(id, d) {
        if (!db.select({ id: aula.id }).from(aula).where(eq(aula.id, id)).get())
            throw new ErroNaoEncontrado('Aula não encontrada');
        return db.update(aula).set({ ...d, atualizadoEm: new Date().toISOString() }).where(eq(aula.id, id)).returning().get();
    }
    return { doDia, listar, criar, atualizar, inscrever, inscritos, alunosInscritos };
}
